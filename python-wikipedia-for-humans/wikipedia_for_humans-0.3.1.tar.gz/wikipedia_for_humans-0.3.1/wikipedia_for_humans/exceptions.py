
class DisambiguationError(Exception):
    """ Disambiguation page """
