<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
<context>
    <name>about_page</name>
    <message>
        <location filename="about_page.qml" line="45"/>
        <source>About</source>
        <translation>Over</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="77"/>
        <source>System Information</source>
        <translation>Systeeminformatie</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="89"/>
        <source>Kernel Version</source>
        <translation>Kernelversie</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="105"/>
        <source>Version</source>
        <translation>Versie</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="113"/>
        <location filename="about_page.qml" line="122"/>
        <source>Local Address</source>
        <translation>Lokaal adres</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="122"/>
        <source>No Active Connection</source>
        <translation>Geen actieve verbinding</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="165"/>
        <source>Device Settings</source>
        <translation>Apparaat instellingen</translation>
    </message>
</context>
</TS>
