<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>configuration_generator_display</name>
    <message>
        <location filename="configuration_generator_display.qml" line="86"/>
        <source>Configuration</source>
        <translation>Configuração</translation>
    </message>
    <message>
        <location filename="configuration_generator_display.qml" line="279"/>
        <source>Back</source>
        <translation>De volta</translation>
    </message>
    <message>
        <location filename="configuration_generator_display.qml" line="309"/>
        <source>Update Settings</source>
        <translation>Atualizar configurações</translation>
    </message>
</context>
</TS>
