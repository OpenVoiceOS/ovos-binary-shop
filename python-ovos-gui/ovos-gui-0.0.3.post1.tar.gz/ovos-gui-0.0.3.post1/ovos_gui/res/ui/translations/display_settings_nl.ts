<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
<context>
    <name>display_settings</name>
    <message>
        <location filename="display_settings.qml" line="47"/>
        <source>Display Settings</source>
        <translation>Scherminstellingen</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="78"/>
        <source>Wallpaper Rotation</source>
        <translation>Achtergrondrotatie</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="89"/>
        <source>Changes the wallpaper automatically</source>
        <translation>Verandert de achtergrond automatisch</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="107"/>
        <location filename="display_settings.qml" line="167"/>
        <location filename="display_settings.qml" line="227"/>
        <source>ON</source>
        <translation>AAN</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="107"/>
        <location filename="display_settings.qml" line="167"/>
        <location filename="display_settings.qml" line="227"/>
        <source>OFF</source>
        <translation>UIT</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="138"/>
        <source>Auto Dim</source>
        <translation>Automatisch dimmen</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="149"/>
        <source>Dim&apos;s the display in 60 seconds</source>
        <translation>Dim het display in 60 seconden</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="198"/>
        <source>Auto Nightmode</source>
        <translation>Automatische nachtmodus</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="209"/>
        <source>Activates nightmode on homescreen, depending on the time of the day</source>
        <translation>Activeert de nachtmodus op het startscherm, afhankelijk van het tijdstip van de dag</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="284"/>
        <source>Device Settings</source>
        <translation>Apparaat instellingen</translation>
    </message>
</context>
</TS>
