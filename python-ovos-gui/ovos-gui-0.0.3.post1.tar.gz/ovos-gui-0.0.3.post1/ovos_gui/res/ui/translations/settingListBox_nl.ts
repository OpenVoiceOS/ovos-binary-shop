<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
<context>
    <name>settingListBox</name>
    <message>
        <location filename="configuration_ui/settingListBox.qml" line="183"/>
        <source>Type here to add an item to the list</source>
        <translation>Typ hier om een ​​item aan de lijst toe te voegen</translation>
    </message>
    <message>
        <location filename="configuration_ui/settingListBox.qml" line="196"/>
        <source>Add Item</source>
        <translation>Voeg item toe</translation>
    </message>
</context>
</TS>
