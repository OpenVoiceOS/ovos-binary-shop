<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>settingListBox</name>
    <message>
        <location filename="configuration_ui/settingListBox.qml" line="183"/>
        <source>Type here to add an item to the list</source>
        <translation>Digita qui per aggiungere un elemento all&apos;elenco</translation>
    </message>
    <message>
        <location filename="configuration_ui/settingListBox.qml" line="196"/>
        <source>Add Item</source>
        <translation>Aggiungi articolo</translation>
    </message>
</context>
</TS>
