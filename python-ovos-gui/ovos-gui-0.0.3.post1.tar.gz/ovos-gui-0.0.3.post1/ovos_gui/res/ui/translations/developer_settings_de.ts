<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>developer_settings</name>
    <message>
        <location filename="developer_settings.qml" line="48"/>
        <source>Developer Settings</source>
        <translation>Entwicklereinstellungen</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="117"/>
        <source>Advanced Settings</source>
        <translation>Erweiterte Einstellungen</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="152"/>
        <source>Enable Dashboard</source>
        <translation>Dashboard aktivieren</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="165"/>
        <source>Disable Dashboard</source>
        <translation>Dashboard deaktivieren</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="187"/>
        <source>Dashboard Address</source>
        <translation>Dashboard Adresse</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="197"/>
        <source>Dashboard Username</source>
        <translation>Dashboard Benutzername</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="207"/>
        <source>Dashboard Password</source>
        <translation>Dashboard Passwort</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="250"/>
        <source>Device Settings</source>
        <translation>Geräteeinstellungen</translation>
    </message>
</context>
</TS>
