<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
<context>
    <name>ssh_settings</name>
    <message>
        <location filename="ssh_settings.qml" line="44"/>
        <source>SSH Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ssh_settings.qml" line="67"/>
        <source>By enabling SSH Mode, anyone can access, change or delete anything on this device by connecting to it via another device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ssh_settings.qml" line="78"/>
        <source>Enable SSH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ssh_settings.qml" line="88"/>
        <source>Disable SSH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ssh_settings.qml" line="133"/>
        <source>Device Settings</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
