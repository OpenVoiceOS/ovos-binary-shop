<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>settingListBox</name>
    <message>
        <location filename="configuration_ui/settingListBox.qml" line="183"/>
        <source>Type here to add an item to the list</source>
        <translation>Tapez ici pour ajouter un élément à la liste</translation>
    </message>
    <message>
        <location filename="configuration_ui/settingListBox.qml" line="196"/>
        <source>Add Item</source>
        <translation>Ajouter un item</translation>
    </message>
</context>
</TS>
