<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>homescreen_settings</name>
    <message>
        <location filename="homescreen_settings.qml" line="61"/>
        <source>Homescreen Settings</source>
        <translation>Impostazioni della schermata iniziale</translation>
    </message>
    <message>
        <location filename="homescreen_settings.qml" line="169"/>
        <source>Device Settings</source>
        <translation>Impostazioni dispositivo</translation>
    </message>
</context>
</TS>
