<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>homescreen_settings</name>
    <message>
        <location filename="homescreen_settings.qml" line="61"/>
        <source>Homescreen Settings</source>
        <translation>Einstellungen Homescreen</translation>
    </message>
    <message>
        <location filename="homescreen_settings.qml" line="169"/>
        <source>Device Settings</source>
        <translation>Geräteeinstellungen</translation>
    </message>
</context>
</TS>
