<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>display_settings</name>
    <message>
        <location filename="display_settings.qml" line="47"/>
        <source>Display Settings</source>
        <translation>Paramètres d&apos;affichage</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="78"/>
        <source>Wallpaper Rotation</source>
        <translation>Rotation du papier peint</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="89"/>
        <source>Changes the wallpaper automatically</source>
        <translation>Change automatiquement le fond d&apos;écran</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="107"/>
        <location filename="display_settings.qml" line="167"/>
        <location filename="display_settings.qml" line="227"/>
        <source>ON</source>
        <translation>SUR</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="107"/>
        <location filename="display_settings.qml" line="167"/>
        <location filename="display_settings.qml" line="227"/>
        <source>OFF</source>
        <translation>À L&apos;ARRÊT</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="138"/>
        <source>Auto Dim</source>
        <translation>Atténuation automatique</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="149"/>
        <source>Dim&apos;s the display in 60 seconds</source>
        <translation>Estompe l&apos;affichage en 60 secondes</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="198"/>
        <source>Auto Nightmode</source>
        <translation>Mode nuit automatique</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="209"/>
        <source>Activates nightmode on homescreen, depending on the time of the day</source>
        <translation>Active le mode nuit sur l&apos;écran d&apos;accueil, en fonction de l&apos;heure de la journée</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="284"/>
        <source>Device Settings</source>
        <translation>Réglages de l&apos;appareil</translation>
    </message>
</context>
</TS>
