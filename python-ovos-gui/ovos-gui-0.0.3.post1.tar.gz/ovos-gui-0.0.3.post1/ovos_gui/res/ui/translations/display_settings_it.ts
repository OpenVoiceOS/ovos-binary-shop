<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>display_settings</name>
    <message>
        <location filename="display_settings.qml" line="47"/>
        <source>Display Settings</source>
        <translation>Impostazioni di visualizzazione</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="78"/>
        <source>Wallpaper Rotation</source>
        <translation>Rotazione dello sfondo</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="89"/>
        <source>Changes the wallpaper automatically</source>
        <translation>Cambia automaticamente lo sfondo</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="107"/>
        <location filename="display_settings.qml" line="167"/>
        <location filename="display_settings.qml" line="227"/>
        <source>ON</source>
        <translation>SU</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="107"/>
        <location filename="display_settings.qml" line="167"/>
        <location filename="display_settings.qml" line="227"/>
        <source>OFF</source>
        <translation>SPENTO</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="138"/>
        <source>Auto Dim</source>
        <translation>Oscuramento automatico</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="149"/>
        <source>Dim&apos;s the display in 60 seconds</source>
        <translation>Oscuramento automatico</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="198"/>
        <source>Auto Nightmode</source>
        <translation>Oscuramento automatico</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="209"/>
        <source>Activates nightmode on homescreen, depending on the time of the day</source>
        <translation>Attiva la modalità notturna sulla schermata iniziale, a seconda dell&apos;ora del giorno</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="284"/>
        <source>Device Settings</source>
        <translation>Impostazioni dispositivo</translation>
    </message>
</context>
</TS>
