<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
<context>
    <name>customize_settings</name>
    <message>
        <location filename="customize_settings.qml" line="60"/>
        <source>Customize Settings</source>
        <translation>Instellingen aanpassen</translation>
    </message>
    <message>
        <location filename="customize_settings.qml" line="264"/>
        <source>Device Settings</source>
        <translation>Apparaat instellingen</translation>
    </message>
    <message>
        <location filename="customize_settings.qml" line="294"/>
        <source>Create Scheme</source>
        <translation>Schema maken</translation>
    </message>
    <message>
        <location filename="customize_settings.qml" line="399"/>
        <source>Select Style</source>
        <translation>Selecteer stijl</translation>
    </message>
    <message>
        <location filename="customize_settings.qml" line="468"/>
        <source>Cancel</source>
        <translation>Annuleren</translation>
    </message>
</context>
</TS>
