<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>customize_theme</name>
    <message>
        <location filename="customize_theme.qml" line="35"/>
        <source>Example Scheme</source>
        <translation>Schema di esempio</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="83"/>
        <source>Create Scheme</source>
        <translation>Crea schema</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="142"/>
        <source>Select Primary Color</source>
        <translation>Seleziona Colore primario</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="184"/>
        <source>Select Secondary Color</source>
        <translation>Seleziona Colore secondario</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="226"/>
        <source>Auto Text Color</source>
        <translation>Colore testo automatico</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="260"/>
        <source>Set Name</source>
        <translation>Imposta nome</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="322"/>
        <location filename="customize_theme.qml" line="509"/>
        <source>Preview</source>
        <translation>Anteprima</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="378"/>
        <source>Create</source>
        <translation>Creare</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="439"/>
        <source>Back</source>
        <translation>Di ritorno</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="580"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
</context>
</TS>
