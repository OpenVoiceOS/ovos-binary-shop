<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>configuration_groups_display</name>
    <message>
        <location filename="configuration_groups_display.qml" line="43"/>
        <source>Advanced Configuration</source>
        <translation>Configuración avanzada</translation>
    </message>
    <message>
        <location filename="configuration_groups_display.qml" line="152"/>
        <source>Back</source>
        <translation>atrás</translation>
    </message>
</context>
</TS>
