<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>about_page</name>
    <message>
        <location filename="about_page.qml" line="45"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="77"/>
        <source>System Information</source>
        <translation>Informação do sistema</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="89"/>
        <source>Kernel Version</source>
        <translation>Versão do kernel</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="105"/>
        <source>Version</source>
        <translation>Versão</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="113"/>
        <location filename="about_page.qml" line="122"/>
        <source>Local Address</source>
        <translation>Endereço local</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="122"/>
        <source>No Active Connection</source>
        <translation>Sem conexão ativa</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="165"/>
        <source>Device Settings</source>
        <translation>Configurações do dispositivo</translation>
    </message>
</context>
</TS>
