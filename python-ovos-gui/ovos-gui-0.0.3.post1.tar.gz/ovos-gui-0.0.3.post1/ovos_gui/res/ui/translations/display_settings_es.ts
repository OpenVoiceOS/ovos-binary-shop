<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>display_settings</name>
    <message>
        <location filename="display_settings.qml" line="47"/>
        <source>Display Settings</source>
        <translation>Configuración de pantalla</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="78"/>
        <source>Wallpaper Rotation</source>
        <translation>Rotación de papel tapiz</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="89"/>
        <source>Changes the wallpaper automatically</source>
        <translation>Cambia el fondo de pantalla automáticamente</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="107"/>
        <location filename="display_settings.qml" line="167"/>
        <location filename="display_settings.qml" line="227"/>
        <source>ON</source>
        <translation>EN</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="107"/>
        <location filename="display_settings.qml" line="167"/>
        <location filename="display_settings.qml" line="227"/>
        <source>OFF</source>
        <translation>APAGADO</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="138"/>
        <source>Auto Dim</source>
        <translation>Atenuación automática</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="149"/>
        <source>Dim&apos;s the display in 60 seconds</source>
        <translation>Oscurece la pantalla en 60 segundos</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="198"/>
        <source>Auto Nightmode</source>
        <translation>Modo nocturno automático</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="209"/>
        <source>Activates nightmode on homescreen, depending on the time of the day</source>
        <translation>Activa el modo nocturno en la pantalla de inicio, según la hora del día</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="284"/>
        <source>Device Settings</source>
        <translation>Configuración de dispositivo</translation>
    </message>
</context>
</TS>
