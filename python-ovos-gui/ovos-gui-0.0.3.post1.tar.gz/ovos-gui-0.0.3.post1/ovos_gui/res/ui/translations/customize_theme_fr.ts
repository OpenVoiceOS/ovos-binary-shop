<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>customize_theme</name>
    <message>
        <location filename="customize_theme.qml" line="35"/>
        <source>Example Scheme</source>
        <translation>Exemple de schéma</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="83"/>
        <source>Create Scheme</source>
        <translation>Créer un schéma</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="142"/>
        <source>Select Primary Color</source>
        <translation>Sélectionnez la couleur primaire</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="184"/>
        <source>Select Secondary Color</source>
        <translation>Sélectionnez la couleur secondaire</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="226"/>
        <source>Auto Text Color</source>
        <translation>Couleur du texte automatique</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="260"/>
        <source>Set Name</source>
        <translation>Définir le nom</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="322"/>
        <location filename="customize_theme.qml" line="509"/>
        <source>Preview</source>
        <translation>Aperçu</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="378"/>
        <source>Create</source>
        <translation>Créer</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="439"/>
        <source>Back</source>
        <translation>Retour</translation>
    </message>
    <message>
        <location filename="customize_theme.qml" line="580"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
</context>
</TS>
