<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>customize_settings</name>
    <message>
        <location filename="customize_settings.qml" line="60"/>
        <source>Customize Settings</source>
        <translation>Personalizar la configuración</translation>
    </message>
    <message>
        <location filename="customize_settings.qml" line="264"/>
        <source>Device Settings</source>
        <translation>Configuración de dispositivo</translation>
    </message>
    <message>
        <location filename="customize_settings.qml" line="294"/>
        <source>Create Scheme</source>
        <translation>Crear esquema</translation>
    </message>
    <message>
        <location filename="customize_settings.qml" line="399"/>
        <source>Select Style</source>
        <translation>Seleccionar estilo</translation>
    </message>
    <message>
        <location filename="customize_settings.qml" line="468"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
</TS>
