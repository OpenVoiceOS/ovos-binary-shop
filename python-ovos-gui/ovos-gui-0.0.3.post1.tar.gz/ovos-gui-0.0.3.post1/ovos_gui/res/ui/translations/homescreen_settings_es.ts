<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>homescreen_settings</name>
    <message>
        <location filename="homescreen_settings.qml" line="61"/>
        <source>Homescreen Settings</source>
        <translation>Configuración de la pantalla de inicio</translation>
    </message>
    <message>
        <location filename="homescreen_settings.qml" line="169"/>
        <source>Device Settings</source>
        <translation>Configuración de dispositivo</translation>
    </message>
</context>
</TS>
