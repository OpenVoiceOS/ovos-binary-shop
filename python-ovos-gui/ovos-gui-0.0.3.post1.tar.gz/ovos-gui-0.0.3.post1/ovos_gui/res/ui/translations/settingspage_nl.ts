<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
<context>
    <name>settingspage</name>
    <message>
        <location filename="settingspage.qml" line="19"/>
        <source>Homescreen Settings</source>
        <translation>Instellingen startscherm</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="25"/>
        <source>Customize</source>
        <translation>Aanpassen</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="31"/>
        <source>Display</source>
        <translation>Weergave</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="37"/>
        <source>Enable SSH</source>
        <translation>SSH inschakelen</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="43"/>
        <source>Developer Settings</source>
        <translation>Ontwikkelaarsinstellingen</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="49"/>
        <source>About</source>
        <translation>Over</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="68"/>
        <source>Device Settings</source>
        <translation>Apparaat instellingen</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="180"/>
        <source>Home</source>
        <translation>Huis</translation>
    </message>
</context>
</TS>
