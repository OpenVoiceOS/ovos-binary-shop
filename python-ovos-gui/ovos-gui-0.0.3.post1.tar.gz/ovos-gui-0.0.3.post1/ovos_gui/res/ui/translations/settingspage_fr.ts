<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>settingspage</name>
    <message>
        <location filename="settingspage.qml" line="19"/>
        <source>Homescreen Settings</source>
        <translation>Paramètres de l&apos;écran d&apos;accueil</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="25"/>
        <source>Customize</source>
        <translation>Personnaliser</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="31"/>
        <source>Display</source>
        <translation>Affichage</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="37"/>
        <source>Enable SSH</source>
        <translation>Activer SSH</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="43"/>
        <source>Developer Settings</source>
        <translation>Paramètres du développeur</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="49"/>
        <source>About</source>
        <translation>À propos de</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="68"/>
        <source>Device Settings</source>
        <translation>Réglages de l&apos;appareil</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="180"/>
        <source>Home</source>
        <translation>Maison</translation>
    </message>
</context>
</TS>
