cython pycrfsuite/_pycrfsuite.pyx --cplus -a -2 -I pycrfsuite
