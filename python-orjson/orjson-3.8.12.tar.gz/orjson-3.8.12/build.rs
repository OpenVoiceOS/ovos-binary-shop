// SPDX-License-Identifier: (Apache-2.0 OR MIT)

use std::env;

fn main() {
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rerun-if-changed=include/yyjson/*");
    println!("cargo:rerun-if-env-changed=CC");
    println!("cargo:rerun-if-env-changed=CFLAGS");
    println!("cargo:rerun-if-env-changed=LDFLAGS");
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    println!("cargo:rerun-if-env-changed=ORJSON_DISABLE_WRITEEXT");
    println!("cargo:rerun-if-env-changed=ORJSON_DISABLE_YYJSON");
    println!("cargo:rerun-if-env-changed=ORJSON_ENABLE_WRITEEXT");

    let py_cfg = pyo3_build_config::get();
    py_cfg.emit_pyo3_cfgs();

    if let Some(true) = version_check::supports_feature("core_intrinsics") {
        println!("cargo:rustc-cfg=feature=\"intrinsics\"");
    }

    if let Some(true) = version_check::supports_feature("optimize_attribute") {
        println!("cargo:rustc-cfg=feature=\"optimize\"");
    }

    if let Some(true) = version_check::supports_feature("strict_provenance") {
        println!("cargo:rustc-cfg=feature=\"strict_provenance\"");
    }

    if let Some(true) = version_check::supports_feature("trusted_len") {
        println!("cargo:rustc-cfg=feature=\"trusted_len\"");
    }

    if env::var("ORJSON_DISABLE_WRITEEXT").is_ok() {
    } else if env::var("ORJSON_ENABLE_WRITEEXT").is_ok()
        || env::var("CARGO_CFG_TARGET_OS").unwrap() == "macos"
        || env::var("CARGO_CFG_TARGET_ENV").unwrap() == "gnu"
    {
        println!("cargo:rustc-cfg=feature=\"writeext\"");
    }

    if env::var("ORJSON_DISABLE_YYJSON").is_ok() {
        if env::var("CARGO_FEATURE_YYJSON").is_ok() {
            panic!("ORJSON_DISABLE_YYJSON and --features=yyjson both enabled.")
        }
    } else {
        match cc::Build::new()
            .file("include/yyjson/yyjson.c")
            .include("include/yyjson")
            .define("YYJSON_DISABLE_NON_STANDARD", "1")
            .define("YYJSON_DISABLE_UTILS", "1")
            .define("YYJSON_DISABLE_WRITER", "1")
            .try_compile("yyjson")
        {
            Ok(_) => {
                println!("cargo:rustc-cfg=feature=\"yyjson\"");
            }
            Err(_) => {
                if env::var("CARGO_FEATURE_YYJSON").is_ok() {
                    panic!("yyjson was enabled but the build failed. To build with a different backend do not specify the feature.")
                }
            }
        }
    }
}
