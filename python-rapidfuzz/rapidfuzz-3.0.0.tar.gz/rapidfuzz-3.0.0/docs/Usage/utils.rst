rapidfuzz.utils
===============

default_process
---------------
.. autofunction:: rapidfuzz.utils.default_process
