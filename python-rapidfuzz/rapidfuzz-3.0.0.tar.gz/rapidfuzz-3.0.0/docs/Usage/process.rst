rapidfuzz.process
=================

cdist
----------
.. autofunction:: rapidfuzz.process.cdist

extract
-------
.. autofunction:: rapidfuzz.process.extract

extract_iter
------------
.. autofunction:: rapidfuzz.process.extract_iter

extractOne
----------
.. autofunction:: rapidfuzz.process.extractOne
