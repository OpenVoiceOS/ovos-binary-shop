#include <stdbool.h>

bool inside_polygon_int(int x, int y, int nr_coords, int x_coords[],
                        int y_coords[]);
