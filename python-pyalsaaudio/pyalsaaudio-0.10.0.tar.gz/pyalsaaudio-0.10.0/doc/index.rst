alsaaudio documentation
===================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   pyalsaaudio
   terminology
   libalsaaudio

Download
========

* `Download from pypi <https://pypi.python.org/pypi/pyalsaaudio>`_

Github
======

* `Repository <https://github.com/larsimmisch/pyalsaaudio/>`_
* `Bug tracker <https://github.com/larsimmisch/pyalsaaudio/issues>`_

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

