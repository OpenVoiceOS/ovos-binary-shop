#!/bin/sh
cython src/*.pyx src/*.pxd --cplus -a -2
