.. _axes_grid_examples:

.. _axes_grid1-examples-index:

The axes_grid1 module
=====================
