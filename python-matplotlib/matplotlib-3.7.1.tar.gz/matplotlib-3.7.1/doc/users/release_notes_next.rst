:orphan:

Next version
============
.. toctree::
   :maxdepth: 1

   next_whats_new
   ../api/next_api_changes
   github_stats
