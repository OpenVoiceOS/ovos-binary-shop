=============================================
What's new in Matplotlib 3.5.2 (May 02, 2022)
=============================================

For a list of all of the issues and pull requests since the last revision, see
the :ref:`github-stats`.

.. contents:: Table of Contents
   :depth: 4

.. toctree::
   :maxdepth: 4

Windows on ARM support
----------------------

Preliminary support for Windows on arm64 target has been added; this requires
FreeType 2.11 or above.

No binary wheels are available yet but it may be built from source.
