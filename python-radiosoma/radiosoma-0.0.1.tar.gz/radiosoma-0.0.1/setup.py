from setuptools import setup

setup(
    name="radiosoma",
    version="0.0.1",
    description="SomaFM python api",
    license="Apache2",
    author="JarbasAi",
    url="https://github.com/OpenJarbas/radiosoma",
    packages=["radiosoma"]
)
