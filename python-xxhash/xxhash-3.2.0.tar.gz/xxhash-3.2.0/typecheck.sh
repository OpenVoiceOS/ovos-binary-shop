#!/bin/bash

pipenv run python -m mypy tests/*
