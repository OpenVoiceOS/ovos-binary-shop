.. _release_highlights_examples:

Release Highlights
------------------

These examples illustrate the main features of the releases of scikit-learn.
