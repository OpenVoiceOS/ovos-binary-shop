# Documentation for scikit-learn

This directory contains the full manual and website as displayed at
http://scikit-learn.org. See
http://scikit-learn.org/dev/developers/contributing.html#documentation for
detailed information about the documentation. 
