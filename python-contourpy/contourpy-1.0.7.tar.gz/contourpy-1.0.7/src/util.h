#ifndef CONTOURPY_UTIL_H
#define CONTOURPY_UTIL_H

#include "common.h"

namespace contourpy {

class Util
{
public:
    static index_t get_max_threads();
};

} // namespace contourpy

#endif // CONTOURPY_UTIL_H
