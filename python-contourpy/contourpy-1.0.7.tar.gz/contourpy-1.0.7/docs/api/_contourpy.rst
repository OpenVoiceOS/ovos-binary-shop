contourpy._contourpy
--------------------

.. automodule:: contourpy._contourpy
