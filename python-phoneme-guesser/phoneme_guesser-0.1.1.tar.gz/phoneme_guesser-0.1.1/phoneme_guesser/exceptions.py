class CantGuessPhonemesForLang(ValueError):
    pass


class FailedToGuessPhonemes(RuntimeError):
    pass
